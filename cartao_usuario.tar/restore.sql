--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Ubuntu 15.4-1.pgdg20.04+1)
-- Dumped by pg_dump version 15.4 (Ubuntu 15.4-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Cartao credito";
--
-- Name: Cartao credito; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Cartao credito" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'pt_BR.UTF-8';


ALTER DATABASE "Cartao credito" OWNER TO postgres;

\connect -reuse-previous=on "dbname='Cartao credito'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analista; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analista (
    analista_id integer NOT NULL,
    nome character varying(20) NOT NULL
);


ALTER TABLE public.analista OWNER TO postgres;

--
-- Name: analista_analista_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analista_analista_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.analista_analista_id_seq OWNER TO postgres;

--
-- Name: analista_analista_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analista_analista_id_seq OWNED BY public.analista.analista_id;


--
-- Name: cartao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cartao (
    cartao_id integer NOT NULL,
    fechamento_ciclo character varying(20) NOT NULL,
    numero_cartao character varying(20) NOT NULL,
    cvv character varying(3) NOT NULL,
    validade date NOT NULL,
    limite_credito real NOT NULL,
    usuario_id integer NOT NULL,
    produto_id integer NOT NULL,
    solicitacao_id integer
);


ALTER TABLE public.cartao OWNER TO postgres;

--
-- Name: cartao_cartao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cartao_cartao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cartao_cartao_id_seq OWNER TO postgres;

--
-- Name: cartao_cartao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cartao_cartao_id_seq OWNED BY public.cartao.cartao_id;


--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    produto_id integer NOT NULL,
    nome character varying(20) NOT NULL,
    anuidade real NOT NULL,
    operadora character varying NOT NULL,
    limite_max_credito real NOT NULL
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: produto_produto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_produto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_produto_id_seq OWNER TO postgres;

--
-- Name: produto_produto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_produto_id_seq OWNED BY public.produto.produto_id;


--
-- Name: solicitacao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.solicitacao (
    solicitacao_id integer NOT NULL,
    data_criacao date NOT NULL,
    status character varying(20) NOT NULL,
    atualizacao_data date,
    data_finalizacao date,
    usuario_id integer NOT NULL,
    analista_id integer NOT NULL,
    produto_id integer NOT NULL
);


ALTER TABLE public.solicitacao OWNER TO postgres;

--
-- Name: solicitacao_solicitacao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.solicitacao_solicitacao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.solicitacao_solicitacao_id_seq OWNER TO postgres;

--
-- Name: solicitacao_solicitacao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.solicitacao_solicitacao_id_seq OWNED BY public.solicitacao.solicitacao_id;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    usuario_id integer NOT NULL,
    nome_completo character varying(20) NOT NULL,
    renda_mensal character varying(20),
    cpf character varying(11) NOT NULL,
    telefone character varying(20),
    endereco character varying(20) NOT NULL
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: usuario_usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_usuario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_usuario_id_seq OWNER TO postgres;

--
-- Name: usuario_usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_usuario_id_seq OWNED BY public.usuario.usuario_id;


--
-- Name: analista analista_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analista ALTER COLUMN analista_id SET DEFAULT nextval('public.analista_analista_id_seq'::regclass);


--
-- Name: cartao cartao_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartao ALTER COLUMN cartao_id SET DEFAULT nextval('public.cartao_cartao_id_seq'::regclass);


--
-- Name: produto produto_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN produto_id SET DEFAULT nextval('public.produto_produto_id_seq'::regclass);


--
-- Name: solicitacao solicitacao_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.solicitacao ALTER COLUMN solicitacao_id SET DEFAULT nextval('public.solicitacao_solicitacao_id_seq'::regclass);


--
-- Name: usuario usuario_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN usuario_id SET DEFAULT nextval('public.usuario_usuario_id_seq'::regclass);


--
-- Data for Name: analista; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3377.dat

--
-- Data for Name: cartao; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3381.dat

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3375.dat

--
-- Data for Name: solicitacao; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3379.dat

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3373.dat

--
-- Name: analista_analista_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analista_analista_id_seq', 21, true);


--
-- Name: cartao_cartao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cartao_cartao_id_seq', 7, true);


--
-- Name: produto_produto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_produto_id_seq', 10, true);


--
-- Name: solicitacao_solicitacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.solicitacao_solicitacao_id_seq', 8, true);


--
-- Name: usuario_usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_usuario_id_seq', 5, true);


--
-- Name: analista analista_nome_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analista
    ADD CONSTRAINT analista_nome_key UNIQUE (nome);


--
-- Name: analista analista_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analista
    ADD CONSTRAINT analista_pkey PRIMARY KEY (analista_id);


--
-- Name: cartao cartao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartao
    ADD CONSTRAINT cartao_pkey PRIMARY KEY (cartao_id);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (produto_id);


--
-- Name: solicitacao solicitacao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.solicitacao
    ADD CONSTRAINT solicitacao_pkey PRIMARY KEY (solicitacao_id);


--
-- Name: usuario usuario_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_cpf_key UNIQUE (cpf);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (usuario_id);


--
-- Name: usuario usuario_telefone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_telefone_key UNIQUE (telefone);


--
-- Name: solicitacao fk_analista_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.solicitacao
    ADD CONSTRAINT fk_analista_id FOREIGN KEY (analista_id) REFERENCES public.analista(analista_id);


--
-- Name: solicitacao fk_produto_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.solicitacao
    ADD CONSTRAINT fk_produto_id FOREIGN KEY (produto_id) REFERENCES public.produto(produto_id);


--
-- Name: cartao fk_produto_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartao
    ADD CONSTRAINT fk_produto_id FOREIGN KEY (produto_id) REFERENCES public.produto(produto_id);


--
-- Name: cartao fk_solicitacao_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartao
    ADD CONSTRAINT fk_solicitacao_id FOREIGN KEY (solicitacao_id) REFERENCES public.solicitacao(solicitacao_id);


--
-- Name: solicitacao fk_usuario_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.solicitacao
    ADD CONSTRAINT fk_usuario_id FOREIGN KEY (usuario_id) REFERENCES public.usuario(usuario_id);


--
-- Name: cartao fk_usuario_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartao
    ADD CONSTRAINT fk_usuario_id FOREIGN KEY (usuario_id) REFERENCES public.usuario(usuario_id);


--
-- PostgreSQL database dump complete
--

